package br.com.jocaolse.clicksolidario

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
