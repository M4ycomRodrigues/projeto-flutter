import '../../widgets/my_util.dart';
import 'perfil_page_widget.dart' show PerfilPageWidget;
import 'package:flutter/material.dart';

class PerfilPageModel extends FlutterFlowModel<PerfilPageWidget> {
  /// Initialization and disposal methods.

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}

  /// Action blocks are added here.

  /// Additional helper methods are added here.
}
