# click-solidario

A new Flutter project.
